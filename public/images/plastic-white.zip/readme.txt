﻿=== Plastic White Cursor Set ===

By: FlynMaker7 (http://www.rw-designer.com/user/113058) flynmaking6@gmail.com

Download: http://www.rw-designer.com/cursor-set/plastic-white

Author's description:

This set makes your cursor look like something from cookie clicker. (or something like that)

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.